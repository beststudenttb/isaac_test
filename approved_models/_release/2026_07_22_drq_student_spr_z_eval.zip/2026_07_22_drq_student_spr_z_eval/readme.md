# 2026_07_22 DrQ-v2 + 冻结 SPR z，noise env + random_stop（off-policy，arm A，2M 步）

**arm A(同一个 z、只换算法)在 random_stop 任务上的第一个结果:离线 deterministic success 76.6%。** 同日的 4M 版见 `2026_07_22_drq_student_spr_z_4m`(92.2%),那个才是这条线的代表结果;本档留作 2M→4M 的对照。

## 成绩

`best_offline.pt` = `drq_01850112.pt`（step 1,850,112 / update 14,454），128 env × 1 episode 离线评估:

| 指标 | 值 |
| --- | ---: |
| success_rate | **0.7656** |
| fail_rate | 0.0000 |
| timeout_rate | 0.2344 |
| mean_return | 7.21 |
| mean_len | 185 步 |
| final_de_mean | 0.099 m ※ |
| final_xe_mean | 8.19 px ※ |

成功率曲线(`offline_val.csv`,80 个 checkpoint):1.25M 之前恒为 0,1.5M 起飞,2M 收官仍是正斜率。

## ※ final_xe / final_de 的修正

**归档时这两个数是错的(原记 de=0.195 / xe=17.53),已按下述方法修正。**

`src/sb3_env.py` 的 `_reset_idx()` 在 episode 结束时调 `sample_end_state()` 重抽 `end_x`/`end_d`,而 `val/drq_student.py:304` 是在 `env.step()` 返回**之后**才读 `env.end_x` —— 读到的是下一集的新目标,`env.last_px_x` 却是本集达成的位置。等于拿这次的答案对下一题的标准答案。

- 该伪影的理论量级:`end_x ~ U(-20,20)` 两次独立抽样之差 `E|U₁-U₂| = 40/3 = 13.3 px`;`end_d ~ U(1.3,1.8)` → `0.5/3 = 0.167 m`。与原记的错误值量级一致。
- 表里的修正值由 `traj_best_offline.csv` 中 done 前一行残留的旧 `end_x`/`end_d` 重算,128 集全覆盖。
- `offline_val.csv` 的 `final_de_mean`/`final_xe_mean` **两列已置空**:每个 checkpoint 只存了 env0 一集轨迹,无法还原 128 集均值。`success_rate` 等其余列不受影响,best checkpoint 的选取(按 success_rate)也不受影响。
- **只有 `RANDOM_STOP = True` 的跑会中招。** 固定任务下 `sample_end_state` 里 `x_min == x_max`,重抽等于没抽。已核对:除本档与 `_4m` 外,所有历史归档都是 `RANDOM_STOP = False`,其 xe/de 数字干净。

## 配置

- `UPDATES_PER_TICK = 64`(128 env 下 replay ratio 128、总更新 100 万次,与 arm B 对齐)。
- `src/replay.py` 的 `store_images=False`:spr_z 不存图,128 env 的 buffer 只占 ~0.5GB(存图要 154GB)。
- encoder = `spr_encoder.pt`(即 `stage1_sigma_ablation.pt`,md5 cfd52c0f),与 σ 调度消融那次 PPO 逐字节一致。
