# 复现 / 看效果

本 zip 只含 **RL 部分**(actor 策略),critic 已剥离、SRL encoder 单独一份共用。

## 需要的三样

1. 本 zip 解压后的 `best_offline_eval.pt`
2. `spr_encoder_cfd52c0f.pt`(三次跑共用同一个冻结 SPR encoder,md5 cfd52c0f)
   —— **复制到解压目录并改名为 `spr_encoder.pt`**,val 脚本按这个名字找。
3. 代码:`val/drq_student.py`(需含 load_dict 的 critic 可选修改)

## 跑

把解压目录当作 run 目录(里面要有 `spr_encoder.pt` 和 `updates/`),或直接用
`best_offline_eval.pt` 手动加载:agent_cfg 在 checkpoint 里自带。

critic 在 `_release/<name>_critic.pt`,只有续训才需要。

## 看什么

`best_offline_info.txt` 成绩 / `offline_val.csv` 全部 checkpoint 曲线 /
`traj_best_offline.csv` 128 集逐步行为 / `log.csv` 训练曲线 / `config.py` 任务与超参。
