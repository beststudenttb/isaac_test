# 2026_07_22 DrQ-v2 + 冻结 SPR z，noise env + random_stop，4M 步（off-policy，arm A）

**arm A 在 random_stop 任务上的代表结果:离线 deterministic success 92.2%,真实定位误差 5.2px / 0.084m。** 同配置 2M 版见 `2026_07_22_drq_student_spr_z`(76.6%)。

## 成绩

`best_offline.pt` = `drq_03775104.pt`（step 3,775,104 / update 29,493），128 env × 1 episode 离线评估:

| 指标 | 值 |
| --- | ---: |
| success_rate | **0.9219** |
| fail_rate | 0.0000 |
| timeout_rate | 0.0781 |
| mean_return | 9.87 |
| mean_len | 142 步 |
| final_de_mean | 0.084 m ※ |
| final_xe_mean | 5.23 px ※ |

只统计成功的 118 集:**xe 均值 1.15px(最大 3.78)、de 均值 0.037m(最大 0.193)**,全部落在容差(10px / 0.2m)内,零违规。均值里的 5.23px 全部来自 10 集 timeout。

## 成功率曲线（`offline_val.csv`，160 个 checkpoint）

| step | success | timeout |
| ---: | ---: | ---: |
| 0.25M–1.25M | **0.000** | 89–98% |
| 1.50M | 0.070 | 91% |
| 2.00M | 0.500 | 48% |
| 2.50M | 0.758 | 24% |
| 3.00M | 0.875 | 13% |
| 3.75M | **0.922** | 7.8% |
| 4.00M | 0.898 | 10% |

**膝盖由 σ 决定,不是"练够了"。** log 里 σ 首次触底 0.05 在 step 1,500,800,而 `STD_DECAY_STEPS = 1_500_000` —— 成功率恰好从这里起飞。前 1.25M 步成功率恒为 0、timeout 90%+,四分之一的训练时间在做无效探索(σ=0.3 时 stop 动作被噪声淹没,而 `STD_END=0.05` 正好等于 `STOP_EPS`)。

**3M 后进平台期**:后 40 个 checkpoint 均值 0.859、最高 0.922,无趋势。再加步数收益很小。

## ※ final_xe / final_de 的修正

**归档时这两个数是错的(原记 de=0.206 / xe=16.73),已修正。** 根因、证据与修正方法见 `2026_07_22_drq_student_spr_z/readme.md` 的同名小节 —— 简言之,`_reset_idx()` 在 episode 结束时重抽 `end_x`/`end_d`,val 读到的是下一集的目标。`offline_val.csv` 的这两列已置空(每 checkpoint 只有 env0 一集轨迹,无法还原 128 集均值);`success_rate` 及 best 的选取不受影响。

## 读法与遗留

- **2M → 4M:76.6% → 92.2%**,涨幅全部来自 timeout 从 23% 压到 8%。表征没动、算法没动,纯粹是训练步数。
- **精度不是问题**。成功集 xe 1.15px,远好于 10px 容差。此前"xe≈17px 卡住"的说法是上面那个度量伪影,作废。
- 剩下的真问题只有 **timeout 7.8%**,且 fail 恒为 0 —— 策略保守,是"没走到"而非"走错"。
- 最便宜的下一个杠杆:`STD_DECAY_STEPS` 1.5M → 0.5M,验证膝盖是否跟着前移。若前移,这条线的训练时间可砍一半以上;若不前移,也是干净的负结果。
- **arm B(pixels)的 random_stop 数还没有**,在跑。历史上 `2026_07_16_drqv2_noise` 的 99.2% 是 `RANDOM_STOP = False` 的固定任务,不能拿来和本档比。两条线在固定任务上都接近满分(arm A 1.000 / arm B 0.992),random_stop 才是有区分度的那格。

## 配置

`UPDATES_PER_TICK = 64`、`TOTAL_ENV_STEPS = 4_000_000`、128 env、`store_images=False`。encoder = `spr_encoder.pt`(即 `stage1_sigma_ablation.pt`,md5 cfd52c0f)。
